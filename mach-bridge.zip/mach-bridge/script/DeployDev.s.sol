// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Script, console2} from "forge-std/Script.sol";
import {ParticipantRegistry} from "../src/ParticipantRegistry.sol";
import {CBDCToken} from "../src/CBDCToken.sol";
import {SettlementEngine} from "../src/SettlementEngine.sol";

/// @notice LOCAL DEV ONLY. Uses Anvil's public default mnemonic, so every key below is
///         publicly known. Never reuse this script or these keys on any shared network.
///
///   Anvil account 0 -> governance admin
///   Anvil account 1 -> central bank A (jurisdiction CA, issues mCAD)
///   Anvil account 2 -> central bank B (jurisdiction AE, issues mAED)
///   Anvil account 3 -> commercial bank A (payer)
///   Anvil account 4 -> commercial bank B (liquidity provider)
contract DeployDev is Script {
    string internal constant MNEMONIC = "test test test test test test test test test test test junk";

    uint256 internal kAdmin;
    uint256 internal kCbA;
    uint256 internal kCbB;
    uint256 internal kBankA;
    uint256 internal kBankB;

    ParticipantRegistry internal registry;
    SettlementEngine internal engine;
    CBDCToken internal mcad;
    CBDCToken internal maed;

    function run() external {
        kAdmin = vm.deriveKey(MNEMONIC, 0);
        kCbA = vm.deriveKey(MNEMONIC, 1);
        kCbB = vm.deriveKey(MNEMONIC, 2);
        kBankA = vm.deriveKey(MNEMONIC, 3);
        kBankB = vm.deriveKey(MNEMONIC, 4);

        _infra();
        _issuerA();
        _issuerB();
        _corridors();
        _liquidityProvider();
        _payer();

        console2.log("ParticipantRegistry :", address(registry));
        console2.log("SettlementEngine    :", address(engine));
        console2.log("mCAD                :", address(mcad));
        console2.log("mAED                :", address(maed));
        console2.log("admin    :", vm.addr(kAdmin));
        console2.log("cbA/cbB  :", vm.addr(kCbA), vm.addr(kCbB));
        console2.log("bankA/LP :", vm.addr(kBankA), vm.addr(kBankB));
    }

    function _infra() internal {
        vm.startBroadcast(kAdmin);
        registry = new ParticipantRegistry(vm.addr(kAdmin));
        engine = new SettlementEngine(registry, vm.addr(kAdmin));
        registry.addCentralBank(vm.addr(kCbA), "CA", keccak256("mach-cb-ca"));
        registry.addCentralBank(vm.addr(kCbB), "AE", keccak256("mach-cb-ae"));
        vm.stopBroadcast();
    }

    function _issuerA() internal {
        vm.startBroadcast(kCbA);
        mcad = new CBDCToken("Mach CAD", "mCAD", 6, registry, vm.addr(kCbA));
        mcad.setSystemContract(address(engine), true);
        registry.onboardCommercialBank(vm.addr(kBankA), keccak256("mach-bank-a"));
        mcad.mint(vm.addr(kBankA), 1_000_000e6);
        vm.stopBroadcast();
    }

    function _issuerB() internal {
        vm.startBroadcast(kCbB);
        maed = new CBDCToken("Mach AED", "mAED", 6, registry, vm.addr(kCbB));
        maed.setSystemContract(address(engine), true);
        registry.onboardCommercialBank(vm.addr(kBankB), keccak256("mach-bank-b"));
        maed.mint(vm.addr(kBankB), 10_000_000e6);
        vm.stopBroadcast();
    }

    function _corridors() internal {
        vm.startBroadcast(kAdmin);
        engine.setCorridor(address(mcad), address(maed), true);
        engine.setCorridor(address(maed), address(mcad), true);
        vm.stopBroadcast();
    }

    function _liquidityProvider() internal {
        vm.startBroadcast(kBankB);
        maed.approve(address(engine), type(uint256).max);
        // Illustrative rate only: 1 mCAD = 2.7 mAED.
        engine.postQuote(address(mcad), address(maed), 2.7e18, 1_000_000e6, 1 days);
        vm.stopBroadcast();
    }

    function _payer() internal {
        vm.startBroadcast(kBankA);
        mcad.approve(address(engine), type(uint256).max);
        vm.stopBroadcast();
    }
}
