#!/usr/bin/env bash
# Installs Foundry on Ubuntu, pulls dependencies, builds, and runs the tests.
set -euo pipefail

sudo apt-get update
sudo apt-get install -y git curl build-essential pkg-config libssl-dev jq

if [ ! -x "$HOME/.foundry/bin/foundryup" ]; then
  curl -L https://foundry.paradigm.xyz | bash
fi
export PATH="$HOME/.foundry/bin:$PATH"
foundryup

cd "$(dirname "$0")/.."

# forge install needs a git repo
if [ ! -d .git ]; then
  git init -q
  git add -A
  git -c user.name="mach" -c user.email="mach@localhost" commit -qm "initial commit"
fi

forge install OpenZeppelin/openzeppelin-contracts@v5.0.2 foundry-rs/forge-std

forge build
forge test -vv
