#!/usr/bin/env bash
# Starts a local Anvil chain and deploys the MachBridge demo setup to it.
set -euo pipefail
export PATH="$HOME/.foundry/bin:$PATH"
cd "$(dirname "$0")/.."

anvil --chain-id 7777 --block-time 1 > anvil.log 2>&1 &
echo $! > .anvil.pid
sleep 2

forge script script/DeployDev.s.sol --rpc-url http://127.0.0.1:8545 --broadcast

echo
echo "Anvil running (pid $(cat .anvil.pid), log: anvil.log)."
echo "Stop it with: kill \$(cat .anvil.pid)"
