// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";
import {Pausable} from "@openzeppelin/contracts/utils/Pausable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {Math} from "@openzeppelin/contracts/utils/math/Math.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {IERC20Metadata} from "@openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol";
import {IParticipantRegistry} from "./interfaces/IParticipantRegistry.sol";

/// @title SettlementEngine
/// @notice Atomic payment-versus-payment (PvP) settlement between two CBDC tokens.
///
///  Flow:
///   1. Liquidity-provider bank posts a quote (rate, max size, expiry) for a corridor.
///   2. Payer bank submits a payment: tokenIn is escrowed and the quoted rate is locked.
///   3. LP calls fill(): in ONE transaction the LP's tokenOut goes to the payee and the
///      escrowed tokenIn goes to the LP. If anything reverts, nothing moves.
///   4. If the LP never fills, anyone can cancel() after the deadline and the payer is
///      refunded. The LP may also reject early via cancel().
contract SettlementEngine is AccessControl, Pausable, ReentrancyGuard {
    bytes32 public constant PAUSER_ROLE = keccak256("PAUSER_ROLE");

    /// @dev Rates are "whole tokenOut per whole tokenIn", scaled by 1e18. Token decimals
    ///      are handled internally, so 2.7e18 means 1 tokenIn = 2.7 tokenOut.
    uint256 public constant RATE_SCALE = 1e18;
    uint64 public constant MIN_TTL = 30 seconds;
    uint64 public constant MAX_TTL = 1 days;

    enum Status {
        None,
        Pending,
        Filled,
        Cancelled
    }

    struct Quote {
        uint128 rate;
        uint128 maxIn;
        uint64 expiry;
    }

    struct PaymentRequest {
        address lp;
        address tokenIn;
        address tokenOut;
        address payee;
        uint256 amountIn;
        uint256 minAmountOut;
        uint64 ttl;
        bytes32 ref; // off-chain reference, e.g. hash of an ISO 20022 message
    }

    struct Payment {
        address payer;
        address payee;
        address lp;
        address tokenIn;
        address tokenOut;
        uint256 amountIn;
        uint256 amountOut;
        uint64 deadline;
        Status status;
        bytes32 ref;
    }

    IParticipantRegistry public immutable registry;

    /// @dev lp => tokenIn => tokenOut => quote
    mapping(address => mapping(address => mapping(address => Quote))) public quotes;
    /// @dev tokenIn => tokenOut => enabled by governance
    mapping(address => mapping(address => bool)) public corridorEnabled;
    mapping(uint256 => Payment) public payments;
    uint256 public nextPaymentId = 1;

    event CorridorSet(address indexed tokenIn, address indexed tokenOut, bool enabled);
    event QuotePosted(address indexed lp, address indexed tokenIn, address indexed tokenOut, uint128 rate, uint128 maxIn, uint64 expiry);
    event QuoteWithdrawn(address indexed lp, address indexed tokenIn, address indexed tokenOut);
    event PaymentSubmitted(uint256 indexed id, address indexed payer, address indexed lp, uint256 amountIn, uint256 amountOut, uint64 deadline, bytes32 ref);
    event PaymentFilled(uint256 indexed id);
    event PaymentCancelled(uint256 indexed id, address indexed by);

    constructor(IParticipantRegistry registry_, address admin) {
        registry = registry_;
        _grantRole(DEFAULT_ADMIN_ROLE, admin);
        _grantRole(PAUSER_ROLE, admin);
    }

    // ----------------------------------------------------------------- governance

    function setCorridor(address tokenIn, address tokenOut, bool enabled) external onlyRole(DEFAULT_ADMIN_ROLE) {
        require(tokenIn != tokenOut, "same token");
        corridorEnabled[tokenIn][tokenOut] = enabled;
        emit CorridorSet(tokenIn, tokenOut, enabled);
    }

    function pause() external onlyRole(PAUSER_ROLE) {
        _pause();
    }

    function unpause() external onlyRole(PAUSER_ROLE) {
        _unpause();
    }

    // ------------------------------------------------------------------ LP quotes

    function postQuote(address tokenIn, address tokenOut, uint128 rate, uint128 maxIn, uint64 validFor)
        external
        whenNotPaused
    {
        require(registry.isTransactor(msg.sender), "not participant");
        require(corridorEnabled[tokenIn][tokenOut], "corridor disabled");
        require(rate > 0 && maxIn > 0 && validFor > 0, "bad quote");
        uint64 expiry = uint64(block.timestamp) + validFor;
        quotes[msg.sender][tokenIn][tokenOut] = Quote({rate: rate, maxIn: maxIn, expiry: expiry});
        emit QuotePosted(msg.sender, tokenIn, tokenOut, rate, maxIn, expiry);
    }

    function withdrawQuote(address tokenIn, address tokenOut) external {
        delete quotes[msg.sender][tokenIn][tokenOut];
        emit QuoteWithdrawn(msg.sender, tokenIn, tokenOut);
    }

    // ------------------------------------------------------------------- payments

    /// @notice Payer must first approve this contract to spend `amountIn` of tokenIn.
    function submitPayment(PaymentRequest calldata req) external whenNotPaused nonReentrant returns (uint256 id) {
        require(registry.isTransactor(msg.sender), "payer not participant");
        require(registry.isTransactor(req.payee), "payee not participant");
        require(registry.isTransactor(req.lp), "lp not participant");
        require(req.ttl >= MIN_TTL && req.ttl <= MAX_TTL, "bad ttl");

        uint256 amountOut = _price(req);
        require(amountOut >= req.minAmountOut, "slippage");

        id = nextPaymentId++;
        uint64 deadline = uint64(block.timestamp) + req.ttl;
        payments[id] = Payment({
            payer: msg.sender,
            payee: req.payee,
            lp: req.lp,
            tokenIn: req.tokenIn,
            tokenOut: req.tokenOut,
            amountIn: req.amountIn,
            amountOut: amountOut,
            deadline: deadline,
            status: Status.Pending,
            ref: req.ref
        });

        require(IERC20(req.tokenIn).transferFrom(msg.sender, address(this), req.amountIn), "escrow failed");
        emit PaymentSubmitted(id, msg.sender, req.lp, req.amountIn, amountOut, deadline, req.ref);
    }

    /// @notice LP settles the payment. LP must have approved this contract for tokenOut.
    function fill(uint256 id) external whenNotPaused nonReentrant {
        Payment storage p = payments[id];
        require(p.status == Status.Pending, "not pending");
        require(msg.sender == p.lp, "only lp");
        require(block.timestamp <= p.deadline, "expired");

        p.status = Status.Filled;
        require(IERC20(p.tokenOut).transferFrom(p.lp, p.payee, p.amountOut), "lp leg failed");
        require(IERC20(p.tokenIn).transfer(p.lp, p.amountIn), "payer leg failed");
        emit PaymentFilled(id);
    }

    /// @notice Refund the payer. Anyone after the deadline; the LP at any time (reject).
    ///         Deliberately not pausable, so escrowed funds are never trapped by a pause.
    function cancel(uint256 id) external nonReentrant {
        Payment storage p = payments[id];
        require(p.status == Status.Pending, "not pending");
        require(block.timestamp > p.deadline || msg.sender == p.lp, "not cancellable yet");

        p.status = Status.Cancelled;
        require(IERC20(p.tokenIn).transfer(p.payer, p.amountIn), "refund failed");
        emit PaymentCancelled(id, msg.sender);
    }

    // ------------------------------------------------------------------- internal

    function _price(PaymentRequest calldata req) internal view returns (uint256) {
        require(corridorEnabled[req.tokenIn][req.tokenOut], "corridor disabled");
        Quote memory q = quotes[req.lp][req.tokenIn][req.tokenOut];
        require(q.expiry >= block.timestamp, "quote expired");
        require(req.amountIn > 0 && req.amountIn <= q.maxIn, "size out of bounds");

        uint256 decIn = IERC20Metadata(req.tokenIn).decimals();
        uint256 decOut = IERC20Metadata(req.tokenOut).decimals();
        uint256 out = Math.mulDiv(
            req.amountIn, uint256(q.rate) * (uint256(10) ** decOut), RATE_SCALE * (uint256(10) ** decIn)
        );
        require(out > 0, "zero output");
        return out;
    }
}
