// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

interface IParticipantRegistry {
    /// @return true if `account` is an active central bank (validator-tier participant).
    function isCentralBank(address account) external view returns (bool);

    /// @return true if `account` is an active central bank or commercial bank,
    ///         i.e. allowed to hold and move wholesale CBDC.
    function isTransactor(address account) external view returns (bool);
}
