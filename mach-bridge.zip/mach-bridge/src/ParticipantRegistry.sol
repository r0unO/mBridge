// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";
import {IParticipantRegistry} from "./interfaces/IParticipantRegistry.sol";

/// @title ParticipantRegistry
/// @notice Membership layer of MachBridge. Mirrors the mBridge model: central banks
///         are admitted by the governance body (DEFAULT_ADMIN_ROLE), and each central
///         bank then onboards and can suspend its own commercial banks.
contract ParticipantRegistry is AccessControl, IParticipantRegistry {
    enum Tier {
        None,
        CentralBank,
        CommercialBank,
        Observer
    }

    struct Participant {
        Tier tier;
        bool active;
        bytes2 jurisdiction; // ISO 3166-1 alpha-2, e.g. "CA"
        address sponsor; // central bank that onboarded a commercial bank
        bytes32 leiHash; // keccak256 of the entity's LEI (kept off-chain)
    }

    mapping(address => Participant) private _participants;

    event ParticipantAdded(address indexed account, Tier tier, bytes2 jurisdiction, address indexed sponsor);
    event ParticipantActiveSet(address indexed account, bool active, address indexed by);

    constructor(address admin) {
        _grantRole(DEFAULT_ADMIN_ROLE, admin);
    }

    // ---------------------------------------------------------------- onboarding

    /// @notice Governance admits a central bank (a validator-tier participant).
    function addCentralBank(address account, bytes2 jurisdiction, bytes32 leiHash)
        external
        onlyRole(DEFAULT_ADMIN_ROLE)
    {
        _add(account, Tier.CentralBank, jurisdiction, address(0), leiHash);
    }

    /// @notice Governance admits a read-only observer (cannot hold or move tokens).
    function addObserver(address account, bytes2 jurisdiction, bytes32 leiHash)
        external
        onlyRole(DEFAULT_ADMIN_ROLE)
    {
        _add(account, Tier.Observer, jurisdiction, address(0), leiHash);
    }

    /// @notice An active central bank onboards a commercial bank in its own jurisdiction.
    function onboardCommercialBank(address account, bytes32 leiHash) external {
        Participant storage cb = _participants[msg.sender];
        require(cb.tier == Tier.CentralBank && cb.active, "caller not active central bank");
        _add(account, Tier.CommercialBank, cb.jurisdiction, msg.sender, leiHash);
    }

    /// @notice Suspend or reinstate a participant. Callable by governance, or by the
    ///         sponsoring central bank for its own commercial banks.
    function setActive(address account, bool active) external {
        Participant storage p = _participants[account];
        require(p.tier != Tier.None, "unknown participant");
        bool byAdmin = hasRole(DEFAULT_ADMIN_ROLE, msg.sender);
        bool bySponsor = p.sponsor != address(0) && p.sponsor == msg.sender && _participants[msg.sender].active;
        require(byAdmin || bySponsor, "not authorised");
        p.active = active;
        emit ParticipantActiveSet(account, active, msg.sender);
    }

    // --------------------------------------------------------------------- views

    function participant(address account) external view returns (Participant memory) {
        return _participants[account];
    }

    function isCentralBank(address account) external view override returns (bool) {
        Participant storage p = _participants[account];
        return p.active && p.tier == Tier.CentralBank;
    }

    function isTransactor(address account) external view override returns (bool) {
        Participant storage p = _participants[account];
        return p.active && (p.tier == Tier.CentralBank || p.tier == Tier.CommercialBank);
    }

    // ------------------------------------------------------------------ internal

    function _add(address account, Tier tier, bytes2 jurisdiction, address sponsor, bytes32 leiHash) internal {
        require(account != address(0), "zero address");
        require(_participants[account].tier == Tier.None, "already registered");
        _participants[account] =
            Participant({tier: tier, active: true, jurisdiction: jurisdiction, sponsor: sponsor, leiHash: leiHash});
        emit ParticipantAdded(account, tier, jurisdiction, sponsor);
    }
}
