// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";
import {Pausable} from "@openzeppelin/contracts/utils/Pausable.sol";
import {IParticipantRegistry} from "./interfaces/IParticipantRegistry.sol";

/// @title CBDCToken
/// @notice One wholesale token per currency. Only the issuing central bank can mint
///         or burn, and only registered, non-frozen participants (or whitelisted
///         system contracts such as the SettlementEngine) can hold it.
/// @dev SIMULATED CBDC for a private consortium. It is not legal tender.
contract CBDCToken is ERC20, AccessControl, Pausable {
    bytes32 public constant ISSUER_ROLE = keccak256("ISSUER_ROLE");
    bytes32 public constant COMPLIANCE_ROLE = keccak256("COMPLIANCE_ROLE");

    IParticipantRegistry public immutable registry;
    uint8 private immutable _tokenDecimals;

    mapping(address => bool) public frozen;
    mapping(address => bool) public systemContract;

    event Frozen(address indexed account, bool isFrozen);
    event SystemContractSet(address indexed account, bool enabled);

    constructor(
        string memory name_,
        string memory symbol_,
        uint8 decimals_,
        IParticipantRegistry registry_,
        address issuer
    ) ERC20(name_, symbol_) {
        require(registry_.isCentralBank(issuer), "issuer not central bank");
        registry = registry_;
        _tokenDecimals = decimals_;
        _grantRole(DEFAULT_ADMIN_ROLE, issuer);
        _grantRole(ISSUER_ROLE, issuer);
        _grantRole(COMPLIANCE_ROLE, issuer);
    }

    function decimals() public view override returns (uint8) {
        return _tokenDecimals;
    }

    // ------------------------------------------------------------------- issuance

    function mint(address to, uint256 amount) external onlyRole(ISSUER_ROLE) {
        _mint(to, amount);
    }

    /// @notice Burns from the issuer's own balance. Banks redeem by transferring to the issuer.
    function burn(uint256 amount) external onlyRole(ISSUER_ROLE) {
        _burn(msg.sender, amount);
    }

    // ----------------------------------------------------------------- compliance

    function setFrozen(address account, bool isFrozen) external onlyRole(COMPLIANCE_ROLE) {
        frozen[account] = isFrozen;
        emit Frozen(account, isFrozen);
    }

    function setSystemContract(address account, bool enabled) external onlyRole(DEFAULT_ADMIN_ROLE) {
        systemContract[account] = enabled;
        emit SystemContractSet(account, enabled);
    }

    function pause() external onlyRole(ISSUER_ROLE) {
        _pause();
    }

    function unpause() external onlyRole(ISSUER_ROLE) {
        _unpause();
    }

    // ---------------------------------------------------------------------- hooks

    function _update(address from, address to, uint256 value) internal override {
        _requireNotPaused();
        if (from != address(0)) _checkHolder(from);
        if (to != address(0)) _checkHolder(to);
        super._update(from, to, value);
    }

    function _checkHolder(address account) internal view {
        require(!frozen[account], "frozen");
        require(systemContract[account] || registry.isTransactor(account), "not participant");
    }
}
