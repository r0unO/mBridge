// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Test} from "forge-std/Test.sol";
import {ParticipantRegistry} from "../src/ParticipantRegistry.sol";
import {CBDCToken} from "../src/CBDCToken.sol";
import {SettlementEngine} from "../src/SettlementEngine.sol";

contract SettlementTest is Test {
    ParticipantRegistry registry;
    CBDCToken cad;
    CBDCToken aed;
    SettlementEngine engine;

    address admin;
    address cbCA;
    address cbAE;
    address bankCA; // payer bank
    address lpAE; // liquidity provider bank
    address payeeAE; // beneficiary bank
    address stranger;

    uint128 constant RATE = 2.7e18; // 1 mCAD = 2.7 mAED (illustrative)

    function setUp() public {
        admin = address(this);
        cbCA = makeAddr("cbCA");
        cbAE = makeAddr("cbAE");
        bankCA = makeAddr("bankCA");
        lpAE = makeAddr("lpAE");
        payeeAE = makeAddr("payeeAE");
        stranger = makeAddr("stranger");

        registry = new ParticipantRegistry(admin);
        registry.addCentralBank(cbCA, "CA", keccak256("cbCA"));
        registry.addCentralBank(cbAE, "AE", keccak256("cbAE"));

        vm.prank(cbCA);
        registry.onboardCommercialBank(bankCA, keccak256("bankCA"));
        vm.startPrank(cbAE);
        registry.onboardCommercialBank(lpAE, keccak256("lpAE"));
        registry.onboardCommercialBank(payeeAE, keccak256("payeeAE"));
        vm.stopPrank();

        engine = new SettlementEngine(registry, admin);
        cad = new CBDCToken("Mach CAD", "mCAD", 6, registry, cbCA);
        aed = new CBDCToken("Mach AED", "mAED", 6, registry, cbAE);

        vm.startPrank(cbCA);
        cad.setSystemContract(address(engine), true);
        cad.mint(bankCA, 1_000_000e6);
        vm.stopPrank();

        vm.startPrank(cbAE);
        aed.setSystemContract(address(engine), true);
        aed.mint(lpAE, 10_000_000e6);
        vm.stopPrank();

        engine.setCorridor(address(cad), address(aed), true);

        vm.startPrank(lpAE);
        aed.approve(address(engine), type(uint256).max);
        engine.postQuote(address(cad), address(aed), RATE, 1_000_000e6, 1 hours);
        vm.stopPrank();

        vm.prank(bankCA);
        cad.approve(address(engine), type(uint256).max);
    }

    function _req(uint256 amountIn, uint256 minOut, address payee, uint64 ttl)
        internal
        view
        returns (SettlementEngine.PaymentRequest memory)
    {
        return SettlementEngine.PaymentRequest({
            lp: lpAE,
            tokenIn: address(cad),
            tokenOut: address(aed),
            payee: payee,
            amountIn: amountIn,
            minAmountOut: minOut,
            ttl: ttl,
            ref: keccak256("pacs.008-demo")
        });
    }

    // ---------------------------------------------------------------- happy path

    function test_endToEndCrossBorderPayment() public {
        vm.prank(bankCA);
        uint256 id = engine.submitPayment(_req(100e6, 270e6, payeeAE, 10 minutes));

        assertEq(cad.balanceOf(address(engine)), 100e6, "escrowed");
        assertEq(cad.balanceOf(bankCA), 999_900e6);

        vm.prank(lpAE);
        engine.fill(id);

        assertEq(aed.balanceOf(payeeAE), 270e6, "payee received mAED");
        assertEq(cad.balanceOf(lpAE), 100e6, "lp received mCAD");
        assertEq(cad.balanceOf(address(engine)), 0, "escrow empty");
        (,,,,,,,, SettlementEngine.Status st,) = engine.payments(id);
        assertEq(uint8(st), uint8(SettlementEngine.Status.Filled));
    }

    // ------------------------------------------------------------ failure paths

    function test_refundAfterDeadline() public {
        vm.prank(bankCA);
        uint256 id = engine.submitPayment(_req(100e6, 0, payeeAE, 10 minutes));

        vm.expectRevert(bytes("not cancellable yet"));
        engine.cancel(id);

        vm.warp(block.timestamp + 11 minutes);
        engine.cancel(id); // anyone may trigger the refund

        assertEq(cad.balanceOf(bankCA), 1_000_000e6, "payer made whole");
        assertEq(cad.balanceOf(address(engine)), 0);
    }

    function test_lpCanRejectEarly() public {
        vm.prank(bankCA);
        uint256 id = engine.submitPayment(_req(100e6, 0, payeeAE, 10 minutes));

        vm.prank(lpAE);
        engine.cancel(id);
        assertEq(cad.balanceOf(bankCA), 1_000_000e6);
    }

    function test_fillAfterDeadlineReverts() public {
        vm.prank(bankCA);
        uint256 id = engine.submitPayment(_req(100e6, 0, payeeAE, 1 minutes));
        vm.warp(block.timestamp + 2 minutes);

        vm.expectRevert(bytes("expired"));
        vm.prank(lpAE);
        engine.fill(id);
    }

    function test_onlyLpCanFill() public {
        vm.prank(bankCA);
        uint256 id = engine.submitPayment(_req(100e6, 0, payeeAE, 10 minutes));

        vm.expectRevert(bytes("only lp"));
        vm.prank(bankCA);
        engine.fill(id);
    }

    function test_slippageProtection() public {
        vm.expectRevert(bytes("slippage"));
        vm.prank(bankCA);
        engine.submitPayment(_req(100e6, 271e6, payeeAE, 10 minutes));
    }

    function test_corridorMustBeEnabled() public {
        engine.setCorridor(address(cad), address(aed), false);
        vm.expectRevert(bytes("corridor disabled"));
        vm.prank(bankCA);
        engine.submitPayment(_req(100e6, 0, payeeAE, 10 minutes));
    }

    function test_unregisteredPayeeRejected() public {
        vm.expectRevert(bytes("payee not participant"));
        vm.prank(bankCA);
        engine.submitPayment(_req(100e6, 0, stranger, 10 minutes));
    }

    function test_pauseBlocksNewPayments() public {
        engine.pause();
        vm.expectRevert();
        vm.prank(bankCA);
        engine.submitPayment(_req(100e6, 0, payeeAE, 10 minutes));
    }

    // ------------------------------------------------------- token / registry

    function test_frozenBeneficiaryBlocksFill() public {
        vm.prank(bankCA);
        uint256 id = engine.submitPayment(_req(100e6, 0, payeeAE, 10 minutes));

        vm.prank(cbAE);
        aed.setFrozen(payeeAE, true);

        vm.expectRevert(bytes("frozen"));
        vm.prank(lpAE);
        engine.fill(id);
    }

    function test_onlyIssuerCanMint() public {
        vm.expectRevert();
        vm.prank(bankCA);
        cad.mint(bankCA, 1e6);
    }

    function test_nonParticipantCannotHoldToken() public {
        vm.expectRevert(bytes("not participant"));
        vm.prank(cbCA);
        cad.mint(stranger, 1e6);
    }

    function test_sponsorCanSuspendItsOwnBankOnly() public {
        vm.prank(cbCA);
        registry.setActive(bankCA, false);
        assertFalse(registry.isTransactor(bankCA));

        vm.expectRevert(bytes("not authorised"));
        vm.prank(cbCA);
        registry.setActive(lpAE, false); // sponsored by cbAE, not cbCA
    }

    function test_commercialBankInheritsJurisdiction() public view {
        ParticipantRegistry.Participant memory p = registry.participant(bankCA);
        assertTrue(p.jurisdiction == bytes2("CA"));
        assertEq(p.sponsor, cbCA);
    }
}
